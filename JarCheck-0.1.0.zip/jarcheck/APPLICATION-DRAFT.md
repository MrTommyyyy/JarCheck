# Claude for Open Source application draft

Status: **not submitted**. The project is new and has not yet been published to GitHub. The live form requires a first name, surname, email, and GitHub repository selection.

## Project reach and impact

I am starting JarCheck, a small MIT-licensed, AI-assisted Python tool for Minecraft mod folders. It works offline, identifies byte-for-byte duplicate JAR files using SHA-256, and checks archive integrity without editing or deleting mods. The initial scanner has seven passing automated tests and includes a desktop interface and contributor documentation. The project is new and has no established download numbers, dependent projects, or external contribution history. Its intended gap is a simple, private way for modpack players to identify accidental duplicate files and damaged archives. I understand this does not currently meet the published adoption or contribution thresholds, and I am requesting discretionary consideration as an early-stage project.

## Intended use of the subscription

I would use Claude to review and understand the code, improve test coverage, document the tool clearly for beginners, and develop carefully tested support for mod-loader metadata. I would also use it to investigate bug reports and prepare maintainable changes while keeping the tool offline and read-only.

Only use these answers if they accurately reflect your plans. The program is designed for established open-source contributions; approval for this new project is unlikely and is not guaranteed. Application: https://claude.com/contact-sales/claude-for-oss
